#pragma once

// your driver bytes does here:
unsigned char driver_data[] = {};